Each of these XML files is one item response. Each filename is composed of the response type and the item ID. Textual responses (SA and WER items) contain "Lorem Ipsum" text to avoid disclosing actual responses.

In actual delivery, the item responses are XML encoded and then embedded in Test Results document according to the Test Results Transmission Format.